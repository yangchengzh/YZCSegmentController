//
//  MainViewController.m
//  YZCSegmentController
//
//  Created by dyso on 16/8/1.
//  Copyright © 2016年 yangzhicheng. All rights reserved.
//

#import "MainViewController.h"
#import "FixedViewController.h"
#import "RandomViewController.h"


#define SCREEN_WIDTH ([UIScreen mainScreen].bounds.size.width)

@interface MainViewController ()<UITabBarControllerDelegate>

@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self markTabbarController];
    
}

- (void)markTabbarController {
    
    _tabBarController = [[UITabBarController alloc] init];
    _tabBarController.delegate = self;
    
    FixedViewController *fixVC = [[FixedViewController alloc] init];
    RandomViewController *randomVC = [[RandomViewController alloc]init];
    
    
    //
    UINavigationController *fixNav = [[UINavigationController alloc] initWithRootViewController:fixVC];
    
    UINavigationController *randomNav = [[UINavigationController alloc] initWithRootViewController:randomVC];
    
    
    _tabBarController.viewControllers = [NSArray arrayWithObjects:
                                         fixNav,
                                         randomNav,
                                         nil];
    
    _tabBarController.delegate = self;
    
    
    [_tabBarController setSelectedIndex:0];
    
    self.tabBar = self.tabBarController.tabBar;
    
    
    
    
    NSArray *barName = [[NSArray alloc]initWithObjects:@"固定的",@"随机的 ", nil];
    
    
    
    for (int a = 0; a<2; a++) {
        self.tabBarItem = [self.tabBar.items objectAtIndex:a];
        [self.tabBarItem setTitle:[barName objectAtIndex:a]];
        
    }
    
    
    UIView *backView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 49)];
    backView.backgroundColor = [UIColor colorWithRed:47/255.0 green:38/255.0 blue:41/255.0 alpha:1.000];
    [self.tabBarController.tabBar insertSubview:backView atIndex:0];
    
    [self.view addSubview:_tabBarController.view];
    
    
    
    
}

@end
