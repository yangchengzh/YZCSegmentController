//
//  FixedViewController.h
//  YZCSegmentController
//
//  Created by dyso on 16/8/1.
//  Copyright © 2016年 yangzhicheng. All rights reserved.
//

#import "YZCViewController.h"

@interface FixedViewController : YZCViewController

@end
