//
//  MainViewController.h
//  YZCSegmentController
//
//  Created by dyso on 16/8/1.
//  Copyright © 2016年 yangzhicheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainViewController : UIViewController

@property (nonatomic, strong) UITabBarController *tabBarController;
@property (retain , nonatomic) UITabBarItem *tabBarItem;
@property (retain , nonatomic) UITabBar *tabBar;

@end
