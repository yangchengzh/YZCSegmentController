//
//  FixedViewController.m
//  YZCSegmentController
//
//  Created by dyso on 16/8/1.
//  Copyright © 2016年 yangzhicheng. All rights reserved.
//

#import "FixedViewController.h"
#import "OneViewController.h"
#import "TwoViewController.h"

@interface FixedViewController ()

@end

@implementation FixedViewController

- (void)viewWillAppear:(BOOL)animated
{
    self.title = @"固定的";
    [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.400 green:0.800 blue:1.000 alpha:1.000]];
    // 标题字体和颜色
    NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:
                                [UIColor whiteColor], NSForegroundColorAttributeName,
                                [UIFont boldSystemFontOfSize:21], NSFontAttributeName,
                                nil];
    [self.navigationController.navigationBar setTitleTextAttributes:attributes];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.titleArray = @[@"one",@"two",@"stree",@"four"];
    
    OneViewController *oneVC = [[OneViewController alloc] init];
    TwoViewController *twoVC = [[TwoViewController alloc] init];
    OneViewController *streeVC = [[OneViewController alloc] init];
    TwoViewController *fourVC = [[TwoViewController alloc] init];
    
    self.controllerArray = @[oneVC,twoVC,streeVC,fourVC];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
